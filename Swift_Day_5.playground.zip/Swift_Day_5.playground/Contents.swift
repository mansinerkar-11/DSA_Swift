import Cocoa


var score: Double = 8.1

if score > 8{
    print("Good your score is \(score) do better next time")
}

//if-else statement


 //else if


// logical opertaor

let userAge: Int = 17
let permission: Bool = true

if userAge >= 18 || permission == true{
    print("You can buy the game")
}else{
    print("You cannot purchase the game")
}


enum transportOption{
    case airplane, hellicopter, car, bicycle, escoter
}

let transport = transportOption.bicycle

if transport == .airplane || transport == .hellicopter{
    print("Let`s fly")
}else if transport == .car{
    print("You will stuck in traffic")
}else if transport == .escoter{
    print("Hope there is E station")
}else{
    print("Hope you will reach on time")
}


let age1 = 18
let age2 = 21

if age1 > 18 || age1 < 18 {
    print("Hello, Swift!")
}


let average1 = 5.0
let average2 = 4.0

if average1 > 5.0 && average2 > 4.0 {
    print("Hello, Swift!")
}
