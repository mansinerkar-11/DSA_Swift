import UIKit

func dash(){
    print("----------------------------------------------------")
    
}
print("""
✅ Swift Basics & Loops✅
Print "Swift is fun!" 4 times without using the loop variable.
Print numbers from 1 to 10 using a for loop.
Create a function that prints “Welcome, <name>!” and call it times with different names.\n\n
""")

dash()

print("Print \"Swift is fun!\" 4 times without using the loop variable.")
for _ in 1...4{
    print("Swift is fun!")
}

dash()
print("Print numbers from 1 to 10 using a for loop.")
for i in 1...10{
    print(i)
}

dash()
print("Create a function that prints “Welcome, <name>!” and call it times with different names.")
func name(name: String)-> Void{
    print("Welcome,\(name) !")
}


name(name:"Mansi")

var names: [String] = ["Mansi","Mau","Lara","Sam","Cat","Nancy"]

for i in names{
    name(name: i)
}
