import Cocoa


// counting


var str: String = "qwertyuiopasdfghjklzxcvbnm"
str.















