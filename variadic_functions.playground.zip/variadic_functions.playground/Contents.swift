import UIKit

func greet(names: String...) {
    for name in names {
        print("Hello, \(name)!")
    }
}

greet(names: "Alice", "Bob", "Charlie")
