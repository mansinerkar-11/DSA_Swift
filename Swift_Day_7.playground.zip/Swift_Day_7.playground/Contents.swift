import Cocoa

var greeting = "Hello, playground"


//FUNCTIONS


func SameStr(strFirst: String, strSecond: String) -> Bool{
    var str1 = strFirst.sorted()
    var str2 = strSecond.sorted()
    
    if str1 == str2{
        return true
    }else{
        return false
    }
}
print("This is return value of function \(SameStr(strFirst: "mauu", strSecond: "uamu"))")



// we can do like this also


func isStringIdentical(string1: String, string2: String) -> Bool{
    return string1.sorted() == string2.sorted()
}

print("This is return value of function \(isStringIdentical(string1: "asdfg", string2: "gfdsa"))")


func pythagorasTheo(a: Double, b: Double) -> Double{
    
    sqrt(a * a + b * b)
    
}

let c = pythagorasTheo(a: 3, b: 4)
print(c)


func format(number: Int) -> String {
    return "The number is \(number)"
}

print(format(number: 2))



// we can use dictionary as a parameter and return type


func getUser() ->[String: String]{
    ["firstName": "Mansi ", "lastName": "Nerkar"]
    
}

var fullName = getUser()
print("Name: \(fullName["firstName" , default: "?"]) \(fullName["lastName", default: "?"])")



// but above code can be like this too

func getUser2() -> (firstName1: String, secondName1: String) {
    (firstName1: "Mansi", secondName1: "Nerkar")
}

var user1 = getUser2()

print("User is \(user1.firstName1) \(user1.secondName1)")


// also we can do this one
func getUser3() -> (firstName1: String, secondName1: String) {
    (firstName1: "Mansi", secondName1: "Nerkar")
}

var (firstName1 , secondName1) = getUser2()

print("User is new \(firstName1) \(secondName1)")

