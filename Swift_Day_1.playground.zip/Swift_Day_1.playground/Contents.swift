import Cocoa

var greeting = "Hello, playground"

//This is variable so that i could change
var myName = "Mansi"
print("My Name is", myName)

myName = "Lara"
print(myName)

myName = "Mau"
print(myName)

let myName_const = "Mansi"
print(myName_const)


let myLongString = """
Hello
this is mansi
and
i am an ios developer
"""
print(myLongString)



let myLongString2 = "My name is mansi and I am 21 \"years\" old lol"
print(myLongString2)


let movie = "Beauty and the beast"
let webSeries = "Strenger things"
let game = "Tomb Raider"
let result = "✨ You Won! ✨"


print(movie.hasPrefix("B"))

print(movie.hasSuffix("ts"))

var strLength = result.count
print("The length of",result, "is ",strLength)

print(result.uppercased())
print(webSeries.lowercased())
