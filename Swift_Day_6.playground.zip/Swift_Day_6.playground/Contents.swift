import Cocoa

var greeting = "Hello, playground"


let names = ["mau", "Mansi"]

for i in names{
    print("\(i) is human")
    
}



//while loop

//we can place random numbers in variable using random function and by specifimg the range


var num1 = Int.random(in: 1...10)
var num2 = Double.random(in: 0...1)


var roll = 0

while roll != 20{
    roll = Int.random(in: 1...20)
    print("I rolled \(roll)")
}

print("\(roll) This was the last number")


//Example of continue

var files = ["photo1.png","photo2.jpg","photo3.png","resume.txt","photo5.jpeg"]

for file in files {
    if file.hasSuffix("png") || file.hasSuffix("jpg") || file.hasSuffix("jpeg") {
        
        continue
        
    }
    else
    {
        print("found text \(file)")
    }
}




//EXAMPLE OF BREAK


let firstVar = 10
let secondVar = 7
var multiples = [Int]()

for i in 1...100_100{
    if i.isMultiple(of: firstVar) && i.isMultiple(of: secondVar){
        if multiples.count == 10{
            break
        }
        
        multiples.append(i)
    }
}
print(multiples)


//CHECKPOINT

//Your goal is to loop from 1 through 100, and for each number:
//• If it's a multiple of 3, print "Fizz".
//• If it's a multiple of 5, print "Buzz".
//• If it's a multiple of 3 and 5, print "FizzBuzz"
//• Otherwise, just print the number.


for i in 1...100{
    if i.isMultiple(of: 3) && i.isMultiple(of: 5){
        print("FizzBuzz")
    }else if i.isMultiple(of: 3){
        print("Fizz")
    }else if i.isMultiple(of: 5){
        print("Buzz")
    }else{
        print(i)
    }
}



