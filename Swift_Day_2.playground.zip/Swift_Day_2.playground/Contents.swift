//Booleans


import Cocoa

var isAuthenticated = false
isAuthenticated = !isAuthenticated
print(isAuthenticated)

isAuthenticated = !isAuthenticated
print(isAuthenticated)


var isHuman = true
isHuman.toggle()
print(isHuman)




let myName = "Mansi"
let yourName = "Lara"

let concUsingPlus = myName + yourName

print(concUsingPlus)



let concExtra = myName + " is not " + yourName
print(concExtra)


let num = "1" + "2" + "3" + "4"
print(num)


let myAge = 22

let message = "my name is \(myName) And my age is \(myAge) Thats it!"
print(message)

//Extra also Optional

let myAgeNow = 21
print("My Age now \(myAgeNow) , Yeah thats true..!!")

//so I want to convert that age number into its spelling so todo that i just need to extend a string function as follow


extension String.StringInterpolation{
    mutating func appendInterpolation(_ value: Int){
        let formatter = NumberFormatter()
        formatter.numberStyle = .spellOut
        
        if let result = formatter.string(from: value as NSNumber)
        {
            appendLiteral(result)
        }
    }
    
    mutating func appendInterpolation(_ value: Date){
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        
        let datestring = formatter.string(from: value)
        appendLiteral(datestring)
    }
    
    
}



print("Today's date is \(Date()) .")

// now whatever the day format is I dont like it so i can manipulate that




//Okay so far it is changing all the numeric into alfabets so what to do just u can add format in _ see how it works

//this is custom behavior

//extension String.StringInterpolation{
//    mutating func appendInterpolation(format value: Int){
//        let formatter = NumberFormatter()
//        formatter.numberStyle = .spellOut
//        
//        if let result = formatter.string(from: value as NSNumber)
//        {
//            appendLiteral(result)
//        }
//    }
//}
//
//print("My Age now \(format: myAgeNow) , Yeah thats true..!!")
//
//
//
//
//
