import Cocoa

var names = ["qwe","rty","yui","vgh","nhg"]
print(names[3])
names.append("uhg")
print(names[5])



var A = Array<Int>()
print(A.count)
A.append(99)
A.append(11)
A.append(10)
A.append(112)
A.append(15)
print(A.count)

A.remove(at: 0)
print(A[0])

A.removeAll()
print(A.count)


var alphabets = Array<String>()
alphabets.append("A")
alphabets.append("B")
alphabets.append("C")
alphabets.append("D")
alphabets.append("E")
alphabets.append("F")
alphabets.append("G")

print(alphabets.contains("M"))


var newArr = [22,55,2,57,36,47,89,33,8,2,55]
print(newArr.sorted())
print(newArr)



var number1 = [1,2,3,4,5,6,7,8,9]
print(number1.reversed())

print(alphabets.reverse())

// this do not reverse the array there are some reasons future mau u are skiping this


//dictionary

var someDicti = [String: String]()
someDicti["mau"] = "Mansi"
someDicti["lara"] = "Croft"
someDicti["monty"] = "Nik"


//print(someDicti["mau"])
print(someDicti["mau", default: "Unknown"])



//Sets


var name3 = Set([1,2,45,6,8,4,3,5,3])
print(name3)
print(name3)


let random = Set(["qwe","ffs","odhd","jsdv","ahgsv"])
print(random)



var names4 = Set<String>()
names4.insert("mau")
names4.insert("lara")
names4.insert("mansi")
names4.insert("Eliza")

print(names4)

names4.insert("mau")
print(names4)




//enum

enum select{
    case monday,tuesday,wednesday,thursday,friday,saturday,sunday
}

var mon = select.monday

print(mon)
print(mon)

