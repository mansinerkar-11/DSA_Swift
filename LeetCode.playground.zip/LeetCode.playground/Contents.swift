import Cocoa

// 1 add two numbers array
//func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
////        var j = 1
//       var res = [Int]()
//        for i in 0..<nums.count {
//            for j in (i + 1)..<nums.count {
//                if nums[i] + nums[j] == target {
//                    res.append(i)
//                    res.append(j)
//                    break
//                }
//        }
//                  
//       }
//        return res
//    }
//
//
//print(twoSum([2,7,11,15],9))




// 2678 Number of senior citizens
//You are given a 0-indexed array of strings details. Each element of details provides information about a given passenger compressed into a string of length 15. The system is such that:
//
//The first ten characters consist of the phone number of passengers.
//The next character denotes the gender of the person.
//The following two characters are used to indicate the age of the person.
//The last two characters determine the seat allotted to that person.
//Return the number of passengers who are strictly more than 60 years old.
//12 and 13

func countSeniors(_ details: [String]) -> Int {
    
    return details.map{
              return Int(String(Array($0)[11...12])) ?? 0
            }.filter{$0 > 60}.count
  }
print(countSeniors(["1313579440F2036","2921522980M5644"]))


