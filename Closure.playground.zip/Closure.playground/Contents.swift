import UIKit

var greeting = "Hello, playground"



let driving = {
    print("I`m Driving a BMW")
}

func travel(action: () -> Void){
    print("I am getting ready to go")
    action()
    print("I am Arrived")
}


travel(action: driving)
