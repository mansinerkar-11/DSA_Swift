import UIKit

var greeting = "Hello, playground"

print(greeting)



let listofPeople:[String] = ["m","g","e","w","q"]


print("----------")
for i in listofPeople{
    print("\(greeting) \(i)")
}
