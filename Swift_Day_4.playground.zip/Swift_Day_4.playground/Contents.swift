import Cocoa

var greeting = "Hello, playground"


//type annotation

let name: String = "Mau"

//Create an array of strings, then write some code that prints the number of items in the array and also the number of unique items in the array.

var names = ["mau","lara","nik","eliza","lzzy","elizabeth","cat","mansi","mau","mau"]

print("The number of items in the array are \(names.count)")


//convert this into sets

var names_set = Set(names)
print("The number of elements in the set are \(names_set.count)")



